public class as2_task1{
  public static void main(String args[]){
    double z = 5+Math.sin(80*Math.PI/180);
    System.out.printf("%.4f", z);
  }
}
