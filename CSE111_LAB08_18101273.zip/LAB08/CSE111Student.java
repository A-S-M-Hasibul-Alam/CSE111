public class CSE111Student extends Student9{
  public String msg = "I love Java Programming";
  public String shout(){
    return msg;
  }
}