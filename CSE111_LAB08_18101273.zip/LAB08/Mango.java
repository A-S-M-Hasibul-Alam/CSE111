public class Mango extends Fruit{
  public Mango(){
    super(true, "Mango");
  }
  public String toString(){
    return "Mangos are bad for you";
  }
}