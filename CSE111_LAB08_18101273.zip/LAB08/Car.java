public class Car{
  public int getObjectCount(int i){
    i=0;
    return i;
  }
  Car(int j){
    getObjectCount()++;
  }
  public int getYear(){
    return j;
  }
}
                      