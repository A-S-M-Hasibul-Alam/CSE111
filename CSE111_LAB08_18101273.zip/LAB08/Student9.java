public class Student9{
  String msg = "I love BU";
  public String shout(){
    return msg;
  }
}
