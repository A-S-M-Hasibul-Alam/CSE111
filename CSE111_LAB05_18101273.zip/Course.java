public class Course{
  String CourseName;
  public Course(String c){
    CourseName = c;
  }
}