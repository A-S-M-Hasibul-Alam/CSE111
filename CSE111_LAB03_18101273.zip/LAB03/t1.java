import java.util.*;
public class t1{
  public static void main(String args[]){
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter a word");
    String s = sc.nextLine();
    int length = s.length();
    System.out.println(length);
  }
}