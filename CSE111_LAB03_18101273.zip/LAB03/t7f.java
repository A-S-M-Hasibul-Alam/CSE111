import java.util.*;
public class t7f{
  public static void main(String args[]){
    Scanner sc = new Scanner(System.in);
    String s = "Hello World";
    String b = "hello world";
    boolean result = s.equalsIgnoreCase(b);
    System.out.println(result);
  }
}