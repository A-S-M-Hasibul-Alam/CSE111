import java.util.*;
public class t7m{
  public static void main(String args[]){
    Scanner sc = new Scanner(System.in);
    String s = "Hello World";
    System.out.println(s.toLowerCase());
  }
}