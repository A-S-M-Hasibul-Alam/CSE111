import java.util.*;
public class t7c{
  public static void main(String args[]){
    Scanner sc = new Scanner(System.in);
    String s = "Hello World";
    String b = "Hello";
    boolean result = s.startsWith(b);
    System.out.println(result);
  }
}