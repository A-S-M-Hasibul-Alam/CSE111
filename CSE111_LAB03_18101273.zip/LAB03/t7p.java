import java.io.*;
public class t7p{
  public static void main(String args[]) {
    double d = 42.12;
    boolean b = true;
    long l = 1342;
    char[] a = {'a', 'b', 'c', 'd', 'e', 'f','g' };
    System.out.println(String.valueOf(d) );
    System.out.println(String.valueOf(b) );
    System.out.println(String.valueOf(l) );
    System.out.println(String.valueOf(a) );
  }
}