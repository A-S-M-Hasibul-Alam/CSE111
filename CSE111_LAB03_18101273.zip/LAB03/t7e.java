import java.util.*;
public class t7e{
  public static void main(String args[]){
    Scanner sc = new Scanner(System.in);
    String s = "Hello World";
    String b = "Hello";
    boolean result = s.equals(b);
    System.out.println(result);
  }
}