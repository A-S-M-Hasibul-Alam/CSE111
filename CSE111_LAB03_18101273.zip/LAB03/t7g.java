import java.util.*;
public class t7g{
  public static void main(String args[]){
    Scanner sc = new Scanner(System.in);
    String s = "TARC gives the sweetest memories";
    String b = "sweetest";
    int result = s.indexOf(b);
    System.out.println(result);
  }
}