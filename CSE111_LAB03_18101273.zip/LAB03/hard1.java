import java.util.*;
public class hard1{
  public static void main(String args[]){
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter a string");
    String s = sc.nextLine();
    int n = s.length();
    int sum = 0;
    for(int i=0; i<n; i++){
      char a = s.charAt(i);
      sum += a;
    }
    if(sum%3==0){
      System.out.println(s+" is divisible by 3");
    }
    else{
    System.out.println(s+" is not divisible by 3");
    }
  }
}
