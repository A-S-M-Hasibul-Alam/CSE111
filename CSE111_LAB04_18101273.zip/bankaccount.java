public class bankaccount{
  public String name;
  public String address;
  public String accountid;
  public double balance;
  public void setName(String n){
    name = n;
  }
  public void setAddress(String a){
    address = a;
  }
  public void setAccountID(String i){
    accountid = i;
  }
  public void setBalance(double c){
    balance = c;
  }
  public double addInterest(){
    double addInterest = balance+balance*0.07;
    return addInterest;  
  }
  public String getName(){
    return name;
  }
  
  public String getAccountID(){
    return accountid;
  }
  
  public String getAddress(){
    return address;
  }
  
  public double getBalance(){
    return balance;
  }
//  public double addInterest(){
//    return addInterest;
}
