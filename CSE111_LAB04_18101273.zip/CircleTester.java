public class CircleTester{
  public static void main(String args[]){
    Circle c = new Circle();
    c.setRadius(4.292);
    System.out.println(c.getArea());
  }
}
