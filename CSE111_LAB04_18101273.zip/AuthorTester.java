public class AuthorTester{
  public static void main(String args[]){
    Author a = new Author();
    a.setFirstName("Arthur");
    a.setLastName("Doyle");
    System.out.print(a.toString());
  }
}